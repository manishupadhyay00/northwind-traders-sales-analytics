USE northwind_traders;
SHOW TABLES;