
from pathlib import Path
import re
import pandas as pd

# ============================================================
# NORTHWIND TRADERS: RELATIONSHIP VALIDATION
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "Data" / "CSV"


def normalize_name(value):
    """Ignore spaces, underscores, hyphens, and capitalization."""
    return re.sub(r"[^a-z0-9]", "", value.lower())


def normalize_id(value):
    """Normalize IDs for comparisons across CSV data types."""
    if pd.isna(value):
        return None

    value = str(value).strip()

    if not value:
        return None

    if re.fullmatch(r"-?\d+\.0+", value):
        value = value.split(".")[0]

    return value


# ------------------------------------------------------------
# 1. Locate and load CSV files
# ------------------------------------------------------------

if not DATA_DIR.exists():
    raise FileNotFoundError(
        f"CSV folder does not exist: {DATA_DIR}"
    )

csv_index = {
    normalize_name(path.stem): path
    for path in DATA_DIR.iterdir()
    if path.is_file() and path.suffix.lower() == ".csv"
}

expected_files = {
    "categories": "categories",
    "customers": "customers",
    "employees": "employees",
    "orders": "orders",
    "order_details": "order_details",
    "products": "products",
    "suppliers": "suppliers",
    "shippers": "shippers",
}

tables = {}

print("=" * 70)
print("NORTHWIND TRADERS - RELATIONSHIP VALIDATION")
print("=" * 70)
print(f"Data directory: {DATA_DIR}")

for table_name, expected_stem in expected_files.items():
    normalized = normalize_name(expected_stem)
    file_path = csv_index.get(normalized)

    if file_path is None:
        raise FileNotFoundError(
            f"Could not find {expected_stem}.csv.\n"
            f"Files available: {[p.name for p in csv_index.values()]}"
        )

    df = pd.read_csv(file_path)
    df.columns = df.columns.str.strip()
    tables[table_name] = df

    print(
        f"Loaded {table_name:<15} "
        f"| Rows: {len(df):>4} "
        f"| File: {file_path.name}"
    )


# ------------------------------------------------------------
# 2. Check primary keys
# ------------------------------------------------------------

primary_keys = {
    "categories": ["CategoryID"],
    "customers": ["CustomerID"],
    "employees": ["EmployeeID"],
    "orders": ["OrderID"],
    "order_details": ["OrderID", "ProductID"],
    "products": ["ProductID"],
    "suppliers": ["SupplierID"],
    "shippers": ["ShipperID"],
}

print("\n" + "=" * 70)
print("PRIMARY KEY CHECKS")
print("=" * 70)

for table_name, key_columns in primary_keys.items():
    df = tables[table_name]

    if not all(column in df.columns for column in key_columns):
        print(f"{table_name}: ERROR - key column missing")
        continue

    null_key_rows = int(
        df[key_columns].isna().any(axis=1).sum()
    )

    normalized_keys = df[key_columns].apply(
        lambda col: col.map(normalize_id)
    )

    duplicate_key_rows = int(
        normalized_keys.duplicated(keep=False).sum()
    )

    status = (
        "PASS"
        if null_key_rows == 0 and duplicate_key_rows == 0
        else "CHECK REQUIRED"
    )

    print(
        f"{table_name:<15} | "
        f"Null key rows: {null_key_rows:<4} | "
        f"Rows in duplicate keys: {duplicate_key_rows:<4} | "
        f"{status}"
    )


# ------------------------------------------------------------
# 3. Check foreign keys
# ------------------------------------------------------------

relationships = [
    ("orders", "CustomerID", "customers", "CustomerID"),
    ("orders", "EmployeeID", "employees", "EmployeeID"),
    ("orders", "ShipVia", "shippers", "ShipperID"),
    ("order_details", "OrderID", "orders", "OrderID"),
    ("order_details", "ProductID", "products", "ProductID"),
    ("products", "CategoryID", "categories", "CategoryID"),
    ("products", "SupplierID", "suppliers", "SupplierID"),
    ("employees", "ReportsTo", "employees", "EmployeeID"),
]

print("\n" + "=" * 70)
print("FOREIGN KEY CHECKS")
print("=" * 70)

for child_name, child_col, parent_name, parent_col in relationships:
    child = tables[child_name]
    parent = tables[parent_name]

    if child_col not in child.columns or parent_col not in parent.columns:
        print(
            f"{child_name}.{child_col} -> "
            f"{parent_name}.{parent_col}: COLUMN MISSING"
        )
        continue

    child_values = child[child_col]
    null_count = int(child_values.isna().sum())

    non_null_values = child_values.dropna().map(normalize_id)

    parent_values = set(
        parent[parent_col]
        .dropna()
        .map(normalize_id)
        .dropna()
    )

    unmatched = non_null_values[
        ~non_null_values.isin(parent_values)
    ]

    unmatched_count = len(unmatched)

    status = "PASS" if unmatched_count == 0 else "CHECK REQUIRED"

    print(
        f"{child_name}.{child_col} -> "
        f"{parent_name}.{parent_col}"
    )
    print(
        f"    Nulls: {null_count} | "
        f"Unmatched values: {unmatched_count} | "
        f"{status}"
    )

    if unmatched_count:
        print(
            "    Examples:",
            unmatched.drop_duplicates().head(10).tolist()
        )


# ------------------------------------------------------------
# 4. Finish
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("VALIDATION FINISHED")
print("No original CSV files were modified.")
print("Review any CHECK REQUIRED results before continuing.")
print("=" * 70)
