
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore", category=FutureWarning)

# ============================================================
# NORTHWIND TRADERS - EXPLORATORY DATA ANALYSIS
# Uses cleaned CSV copies. Does not modify the source data.
# ============================================================

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "Data" / "Processed"
OUTPUT_DIR = ROOT / "Outputs"
CHART_DIR = OUTPUT_DIR / "Charts"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
CHART_DIR.mkdir(parents=True, exist_ok=True)


def load_table(name):
    path = DATA_DIR / f"{name}.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"Missing cleaned file: {path}\n"
            "Run Python/data_cleaning.py first."
        )
    return pd.read_csv(path, encoding="utf-8-sig")


def save_result(df, filename):
    df.to_csv(OUTPUT_DIR / filename, index=False)


def save_bar(df, x, y, title, filename, horizontal=False, top_n=None):
    """Save a reusable bar chart."""
    if df.empty or x not in df.columns or y not in df.columns:
        return

    data = df.dropna(subset=[x, y]).copy()

    if top_n:
        data = data.nlargest(top_n, y)

    if data.empty:
        return

    fig, ax = plt.subplots(figsize=(11, 6))

    if horizontal:
        data = data.sort_values(y)
        ax.barh(data[x].astype(str), data[y])
        ax.set_xlabel(y)
    else:
        ax.bar(data[x].astype(str), data[y])
        ax.set_ylabel(y)
        ax.tick_params(axis="x", rotation=45)

    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(CHART_DIR / filename, dpi=150, bbox_inches="tight")
    plt.close(fig)


def save_hist(series, title, filename, xlabel):
    values = pd.to_numeric(series, errors="coerce").dropna()

    if values.empty:
        return

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.hist(values, bins=25, edgecolor="black")
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Frequency")
    fig.tight_layout()
    fig.savefig(CHART_DIR / filename, dpi=150, bbox_inches="tight")
    plt.close(fig)


def save_line(df, x, y, title, filename, xlabel, ylabel):
    if df.empty:
        return

    fig, ax = plt.subplots(figsize=(11, 6))
    ax.plot(df[x].astype(str), df[y], marker="o")
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=45)
    fig.tight_layout()
    fig.savefig(CHART_DIR / filename, dpi=150, bbox_inches="tight")
    plt.close(fig)


# ------------------------------------------------------------
# 1. Load the eight actual Northwind tables
# ------------------------------------------------------------

categories = load_table("categories")
customers = load_table("customers")
employees = load_table("employees")
details = load_table("order_details")
orders = load_table("orders")
products = load_table("products")
shippers = load_table("shippers")
suppliers = load_table("suppliers")

for column in ["OrderDate", "RequiredDate", "ShippedDate"]:
    if column in orders.columns:
        orders[column] = pd.to_datetime(orders[column], errors="coerce")

for column in ["HireDate", "BirthDate"]:
    if column in employees.columns:
        employees[column] = pd.to_datetime(
            employees[column], errors="coerce"
        )

print("=" * 65)
print("NORTHWIND TRADERS - EDA")
print("=" * 65)
print("All eight cleaned tables loaded.")


# ------------------------------------------------------------
# 2. Prepare sales data and calculate revenue
# ------------------------------------------------------------

for column in ["UnitPrice", "Quantity", "Discount"]:
    details[column] = pd.to_numeric(
        details[column], errors="coerce"
    )

details["Discount"] = details["Discount"].fillna(0)

details["LineRevenue"] = (
    details["UnitPrice"]
    * details["Quantity"]
    * (1 - details["Discount"])
)

# Revenue is calculated at the order-line level.
order_totals = (
    details.groupby("OrderID", as_index=False)
    .agg(
        OrderRevenue=("LineRevenue", "sum"),
        TotalQuantity=("Quantity", "sum"),
        LineCount=("ProductID", "count"),
    )
)

orders_sales = orders.merge(
    order_totals, on="OrderID", how="left"
)

orders_sales["OrderRevenue"] = (
    orders_sales["OrderRevenue"].fillna(0)
)

sales_lines = (
    details.merge(
        orders[["OrderID", "CustomerID", "EmployeeID",
                "OrderDate", "ShipVia"]],
        on="OrderID",
        how="left",
    )
    .merge(
        products[
            ["ProductID", "ProductName", "CategoryID",
             "SupplierID", "UnitPrice", "UnitsInStock",
             "UnitsOnOrder", "ReorderLevel"]
        ].rename(columns={"UnitPrice": "CatalogUnitPrice"}),
        on="ProductID",
        how="left",
    )
    .merge(
        categories[["CategoryID", "CategoryName"]],
        on="CategoryID",
        how="left",
    )
)

# ------------------------------------------------------------
# QUESTION 1: Orders per customer and repeat customers
# ------------------------------------------------------------

customer_orders = (
    orders_sales.groupby("CustomerID", as_index=False)
    .agg(
        OrderCount=("OrderID", "nunique"),
        TotalSpend=("OrderRevenue", "sum"),
    )
)

customer_metrics = customers.merge(
    customer_orders, on="CustomerID", how="left"
)

customer_metrics["OrderCount"] = (
    customer_metrics["OrderCount"].fillna(0).astype(int)
)
customer_metrics["TotalSpend"] = (
    customer_metrics["TotalSpend"].fillna(0)
)

customer_metrics["AverageOrderValue"] = np.where(
    customer_metrics["OrderCount"] > 0,
    customer_metrics["TotalSpend"] / customer_metrics["OrderCount"],
    0,
)

repeat_customers = customer_metrics[
    customer_metrics["OrderCount"] >= 2
].copy()

high_value_threshold = customer_metrics.loc[
    customer_metrics["OrderCount"] >= 2, "TotalSpend"
].quantile(0.75)

customer_metrics["CustomerSegment"] = np.select(
    [
        customer_metrics["OrderCount"].eq(0),
        customer_metrics["OrderCount"].eq(1),
        customer_metrics["OrderCount"].between(2, 5),
        customer_metrics["OrderCount"].gt(5),
    ],
    [
        "No Orders",
        "One-Time Customer",
        "Occasional Customer",
        "Frequent Customer",
    ],
    default="Unclassified",
)

high_value_repeat = repeat_customers[
    repeat_customers["TotalSpend"] >= high_value_threshold
].copy()

average_orders_all_customers = customer_metrics["OrderCount"].mean()
purchasing_customers = customer_metrics[
    customer_metrics["OrderCount"] > 0
]

average_orders_purchasing_customers = (
    purchasing_customers["OrderCount"].mean()
    if not purchasing_customers.empty else 0
)

print("\nQ1 - Customer ordering")
print("Total customers:", len(customers))
print("Customers with at least one order:", len(purchasing_customers))
print("Average orders per customer, including zero-order customers:",
      round(average_orders_all_customers, 2))
print("Average orders among purchasing customers:",
      round(average_orders_purchasing_customers, 2))
print("Repeat customers:", len(repeat_customers))
print("High-value repeat customers (top quartile of repeat-customer spend):",
      len(high_value_repeat))

save_result(customer_metrics, "customer_metrics.csv")
save_result(repeat_customers, "repeat_customers.csv")
save_result(high_value_repeat, "high_value_repeat_customers.csv")
save_result(
    customer_metrics["CustomerSegment"].value_counts()
    .rename_axis("CustomerSegment")
    .reset_index(name="CustomerCount"),
    "customer_segments.csv",
)


# ------------------------------------------------------------
# QUESTION 2: Order patterns by city and country
# ------------------------------------------------------------

location_summary = (
    customer_metrics.groupby(
        ["Country", "City"], dropna=False, as_index=False
    )
    .agg(
        CustomerCount=("CustomerID", "nunique"),
        TotalOrders=("OrderCount", "sum"),
        TotalRevenue=("TotalSpend", "sum"),
    )
    .sort_values("TotalRevenue", ascending=False)
)

country_summary = (
    customer_metrics.groupby("Country", dropna=False, as_index=False)
    .agg(
        CustomerCount=("CustomerID", "nunique"),
        TotalOrders=("OrderCount", "sum"),
        TotalRevenue=("TotalSpend", "sum"),
    )
    .sort_values("TotalRevenue", ascending=False)
)

save_result(location_summary, "customer_city_country_analysis.csv")
save_result(country_summary, "customer_country_analysis.csv")
save_bar(
    country_summary, "Country", "CustomerCount",
    "Customers by Country", "customers_by_country.png",
    horizontal=True, top_n=20,
)


# ------------------------------------------------------------
# QUESTION 3: Customer contact title and region
# ------------------------------------------------------------

for column in ["ContactTitle", "Region"]:
    if column in customers.columns:
        result = (
            customers.groupby(column, dropna=False)
            .size()
            .reset_index(name="CustomerCount")
            .sort_values("CustomerCount", ascending=False)
        )
        save_result(result, f"customers_by_{column.lower()}.csv")


# ------------------------------------------------------------
# QUESTION 4: Revenue by products and categories
# ------------------------------------------------------------

product_sales = (
    sales_lines.groupby(
        ["ProductID", "ProductName"], as_index=False
    )
    .agg(
        QuantitySold=("Quantity", "sum"),
        Revenue=("LineRevenue", "sum"),
        OrderLines=("OrderID", "count"),
    )
    .sort_values("Revenue", ascending=False)
)

category_sales = (
    sales_lines.groupby(
        ["CategoryID", "CategoryName"], as_index=False
    )
    .agg(
        QuantitySold=("Quantity", "sum"),
        Revenue=("LineRevenue", "sum"),
        OrderLines=("OrderID", "count"),
    )
    .sort_values("Revenue", ascending=False)
)

category_sales["RevenueSharePct"] = (
    category_sales["Revenue"]
    / category_sales["Revenue"].sum() * 100
)

save_result(product_sales, "product_sales.csv")
save_result(category_sales, "category_sales.csv")

save_bar(
    category_sales, "CategoryName", "Revenue",
    "Revenue by Product Category", "revenue_by_category.png",
    horizontal=True,
)

save_bar(
    product_sales, "ProductName", "QuantitySold",
    "Top Products by Quantity Sold", "top_products_by_quantity.png",
    horizontal=True, top_n=10,
)


# ------------------------------------------------------------
# QUESTION 5: Order and category patterns by geography
# These are descriptive comparisons, not proof of causation.
# ------------------------------------------------------------

geographic_category = (
    sales_lines.merge(
        customers[["CustomerID", "Country", "City"]],
        on="CustomerID",
        how="left",
    )
    .groupby(["Country", "CategoryName"], dropna=False, as_index=False)
    .agg(
        Revenue=("LineRevenue", "sum"),
        QuantitySold=("Quantity", "sum"),
        OrderCount=("OrderID", "nunique"),
    )
)

save_result(geographic_category, "country_category_patterns.csv")


# ------------------------------------------------------------
# QUESTION 6: Order frequency by customer segment
# ------------------------------------------------------------

segment_frequency = (
    customer_metrics.groupby("CustomerSegment", as_index=False)
    .agg(
        CustomerCount=("CustomerID", "nunique"),
        AverageOrders=("OrderCount", "mean"),
        TotalOrders=("OrderCount", "sum"),
        TotalRevenue=("TotalSpend", "sum"),
    )
)

save_result(segment_frequency, "customer_segment_frequency.csv")


# ------------------------------------------------------------
# QUESTION 7: Employee geographic and title distribution
# ------------------------------------------------------------

employee_group_columns = [
    column for column in ["Country", "City", "Title"]
    if column in employees.columns
]

employee_distribution = (
    employees.groupby(employee_group_columns, dropna=False)
    .size()
    .reset_index(name="EmployeeCount")
)

save_result(employee_distribution, "employee_geographic_title_distribution.csv")

if "Title" in employees.columns:
    title_counts = (
        employees.groupby("Title", dropna=False)
        .size()
        .reset_index(name="EmployeeCount")
    )

    save_result(title_counts, "employee_title_counts.csv")

    save_bar(
        title_counts, "Title", "EmployeeCount",
        "Employees by Job Title", "employees_by_title.png",
        horizontal=True,
    )


# ------------------------------------------------------------
# QUESTION 8: Hire-date trends by employee title
# ------------------------------------------------------------

if "HireDate" in employees.columns:
    hires = employees.dropna(subset=["HireDate"]).copy()
    hires["HireYear"] = hires["HireDate"].dt.year

    hiring_trends = (
        hires.groupby(["HireYear", "Title"], dropna=False)
        .size()
        .reset_index(name="EmployeesHired")
    )

    save_result(hiring_trends, "employee_hiring_trends.csv")


# ------------------------------------------------------------
# QUESTION 9: Courtesy title and reporting structure
# ------------------------------------------------------------

if "TitleOfCourtesy" in employees.columns:
    courtesy_counts = (
        employees.groupby("TitleOfCourtesy", dropna=False)
        .size()
        .reset_index(name="EmployeeCount")
    )
    save_result(courtesy_counts, "employee_courtesy_titles.csv")

# Use the latest order date as the analysis reference date.
# This keeps employee tenure grounded in the historical dataset.
reference_date = orders["OrderDate"].max()

if pd.notna(reference_date) and "HireDate" in employees.columns:
    employees["TenureYearsAtLastOrderDate"] = (
        (reference_date - employees["HireDate"]).dt.days / 365.25
    )

    save_result(
        employees[
            ["EmployeeID", "FirstName", "LastName", "Title",
             "HireDate", "TenureYearsAtLastOrderDate"]
        ],
        "employee_tenure.csv",
    )

    save_hist(
        employees["TenureYearsAtLastOrderDate"],
        "Employee Tenure at Last Order Date",
        "employee_tenure.png",
        "Tenure (years)",
    )

if "ReportsTo" in employees.columns:
    names = (
        employees["FirstName"].fillna("")
        + " "
        + employees["LastName"].fillna("")
    ).str.strip()

    lookup = dict(zip(employees["EmployeeID"], names))
    hierarchy = employees[
        ["EmployeeID", "FirstName", "LastName", "Title", "ReportsTo"]
    ].copy()

    hierarchy["EmployeeName"] = names
    hierarchy["ManagerName"] = hierarchy["ReportsTo"].map(lookup)

    direct_reports = (
        employees.dropna(subset=["ReportsTo"])
        .groupby("ReportsTo")
        .size()
    )

    hierarchy["DirectReportCount"] = (
        hierarchy["EmployeeID"].map(direct_reports).fillna(0).astype(int)
    )

    save_result(hierarchy, "employee_reporting_hierarchy.csv")


# ------------------------------------------------------------
# QUESTION 10: Product price, stock and sales relationship
# ------------------------------------------------------------

product_performance = products.merge(
    product_sales[["ProductID", "QuantitySold", "Revenue"]],
    on="ProductID",
    how="left",
)

for column in ["QuantitySold", "Revenue"]:
    product_performance[column] = product_performance[column].fillna(0)

correlation_columns = [
    column for column in [
        "UnitPrice", "UnitsInStock", "UnitsOnOrder",
        "ReorderLevel", "QuantitySold", "Revenue",
    ]
    if column in product_performance.columns
]

price_stock_correlation = product_performance[
    correlation_columns
].corr(numeric_only=True)

price_stock_correlation.to_csv(
    OUTPUT_DIR / "product_price_stock_sales_correlation.csv"
)

save_result(product_performance, "product_price_stock_sales.csv")


# ------------------------------------------------------------
# QUESTION 11: Monthly and seasonal demand
# ------------------------------------------------------------

monthly_demand = sales_lines.dropna(subset=["OrderDate"]).copy()
monthly_demand["Month"] = (
    monthly_demand["OrderDate"].dt.to_period("M").astype(str)
)

monthly_summary = (
    monthly_demand.groupby("Month", as_index=False)
    .agg(
        Revenue=("LineRevenue", "sum"),
        QuantitySold=("Quantity", "sum"),
        OrderCount=("OrderID", "nunique"),
    )
    .sort_values("Month")
)

save_result(monthly_summary, "monthly_sales_demand.csv")

save_line(
    monthly_summary, "Month", "Revenue",
    "Monthly Revenue Trend", "monthly_revenue.png",
    "Month", "Revenue",
)

save_line(
    monthly_summary, "Month", "QuantitySold",
    "Monthly Product Demand", "monthly_demand.png",
    "Month", "Quantity Sold",
)


# ------------------------------------------------------------
# QUESTION 12: Anomalies in order revenue
# Uses the 1.5 x IQR rule; anomalies require investigation.
# ------------------------------------------------------------

revenue_values = order_totals["OrderRevenue"].dropna()

if not revenue_values.empty:
    q1 = revenue_values.quantile(0.25)
    q3 = revenue_values.quantile(0.75)
    iqr = q3 - q1

    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr

    order_anomalies = order_totals[
        (order_totals["OrderRevenue"] < lower_bound)
        | (order_totals["OrderRevenue"] > upper_bound)
    ].copy()

    save_result(order_anomalies, "order_revenue_anomalies.csv")

    print("\nOrder revenue IQR bounds:")
    print("Lower:", round(lower_bound, 2))
    print("Upper:", round(upper_bound, 2))
    print("Flagged orders:", len(order_anomalies))

    save_hist(
        order_totals["OrderRevenue"],
        "Distribution of Order Values",
        "order_value_distribution.png",
        "Order Revenue",
    )


# ------------------------------------------------------------
# QUESTION 13: Supplier distribution by geography and category
# ------------------------------------------------------------

supplier_products = (
    products.merge(
        suppliers[
            ["SupplierID", "CompanyName", "Country", "City", "Region"]
        ].rename(columns={"CompanyName": "SupplierName"}),
        on="SupplierID",
        how="left",
    )
    .merge(
        categories[["CategoryID", "CategoryName"]],
        on="CategoryID",
        how="left",
    )
)

supplier_counts = (
    supplier_products.groupby(
        ["SupplierID", "SupplierName"], dropna=False, as_index=False
    )
    .agg(
        ProductCount=("ProductID", "nunique"),
        AverageCatalogPrice=("UnitPrice", "mean"),
    )
    .sort_values("ProductCount", ascending=False)
)

supplier_geography = (
    suppliers.groupby(["Country", "City"], dropna=False)
    .size()
    .reset_index(name="SupplierCount")
    .sort_values("SupplierCount", ascending=False)
)

supplier_category_region = (
    supplier_products.groupby(
        ["Country", "Region", "CategoryName"], dropna=False, as_index=False
    )
    .agg(
        SupplierCount=("SupplierID", "nunique"),
        ProductCount=("ProductID", "nunique"),
        AverageCatalogPrice=("UnitPrice", "mean"),
    )
)

supplier_price = (
    supplier_products.groupby(
        ["SupplierID", "SupplierName"], dropna=False, as_index=False
    )
    .agg(
        ProductCount=("ProductID", "nunique"),
        AveragePrice=("UnitPrice", "mean"),
        MinimumPrice=("UnitPrice", "min"),
        MaximumPrice=("UnitPrice", "max"),
    )
)

save_result(supplier_counts, "supplier_product_counts.csv")
save_result(supplier_geography, "supplier_geographic_distribution.csv")
save_result(supplier_category_region, "supplier_category_region_analysis.csv")
save_result(supplier_price, "supplier_pricing_analysis.csv")

save_bar(
    supplier_counts, "SupplierName", "ProductCount",
    "Products Supplied by Supplier", "products_by_supplier.png",
    horizontal=True, top_n=15,
)

save_bar(
    supplier_geography, "Country", "SupplierCount",
    "Suppliers by Country", "suppliers_by_country.png",
    horizontal=True, top_n=20,
)


# ------------------------------------------------------------
# OPTIONAL: Customer clustering using K-Means
# ------------------------------------------------------------

try:
    from sklearn.preprocessing import StandardScaler
    from sklearn.cluster import KMeans

    category_spend = sales_lines.pivot_table(
        index="CustomerID",
        columns="CategoryName",
        values="LineRevenue",
        aggfunc="sum",
        fill_value=0,
    )

    cluster_features = customer_metrics[
        ["CustomerID", "OrderCount", "TotalSpend"]
    ].set_index("CustomerID")

    cluster_features = cluster_features.join(
        category_spend, how="left"
    ).fillna(0)

    if len(cluster_features) >= 4:
        scaled = StandardScaler().fit_transform(cluster_features)

        model = KMeans(
            n_clusters=4,
            random_state=42,
            n_init=10,
        )

        customer_metrics["Cluster"] = model.fit_predict(scaled)

        save_result(
            customer_metrics,
            "customer_clusters.csv",
        )

        print("\nK-Means customer clustering completed (4 clusters).")
        print("Clusters are exploratory and need business interpretation.")

except ImportError:
    print(
        "\nK-Means skipped because scikit-learn is not installed. "
        "Install it with: python -m pip install scikit-learn"
    )


# ------------------------------------------------------------
# FINAL SUMMARY
# ------------------------------------------------------------

print("\n" + "=" * 65)
print("EDA COMPLETED")
print("=" * 65)
print("Reports saved in:", OUTPUT_DIR)
print("Charts saved in:", CHART_DIR)
print("\nTop 5 categories by revenue:")
print(
    category_sales[
        ["CategoryName", "Revenue", "RevenueSharePct"]
    ].head(5).to_string(index=False)
)

print("\nTop 5 products by revenue:")
print(
    product_sales[
        ["ProductName", "QuantitySold", "Revenue"]
    ].head(5).to_string(index=False)
)

print("\nImportant: validate findings before presenting them.")
print("Correlations and anomalies do not by themselves prove causation.")
