
from pathlib import Path
import pandas as pd

# Locate the project folder
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "Data" / "CSV"

csv_files = {
    "categories": "categories.csv",
    "customers": "customers.csv",
    "employees": "employees.csv",
    "order_details": "order_details.csv",
    "orders": "orders.csv",
    "products": "products.csv",
    "shippers": "shippers.csv",
    "suppliers": "suppliers.csv",
}

print("=" * 60)
print("NORTHWIND TRADERS - DATA VALIDATION")
print("=" * 60)
print("Data folder:", DATA_DIR)

for table_name, filename in csv_files.items():
    file_path = DATA_DIR / filename

    if not file_path.exists():
        print(f"\nMISSING FILE: {filename}")
        continue

    try:
        df = pd.read_csv(file_path)

        print(f"\nTABLE: {table_name}")
        print("Rows:", len(df))
        print("Columns:", len(df.columns))
        print("Column names:", df.columns.tolist())
        print("Duplicate rows:", df.duplicated().sum())
        print("Missing values:")
        print(df.isnull().sum().to_string())

    except Exception as error:
        print(f"\nERROR reading {filename}: {error}")

print("\nValidation scan completed.")