
from pathlib import Path
import re
import pandas as pd

# =========================================================
# NORTHWIND TRADERS: DATA CLEANING
# Original CSV files remain unchanged.
# =========================================================

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "Data" / "CSV"
CLEAN_DIR = ROOT / "Data" / "Processed"
OUTPUT_DIR = ROOT / "Outputs"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def normalize_name(name):
    """Ignore spaces, underscores, hyphens, and capitalization."""
    return re.sub(r"[^a-z0-9]", "", name.lower())


def find_csv(expected_name):
    """Find files such as order details.csv or order_details.csv."""
    if not RAW_DIR.exists():
        raise FileNotFoundError(f"Folder not found: {RAW_DIR}")

    target = normalize_name(Path(expected_name).stem)

    for path in RAW_DIR.iterdir():
        if (
            path.is_file()
            and path.suffix.lower() == ".csv"
            and normalize_name(path.stem) == target
        ):
            return path

    raise FileNotFoundError(
        f"Cannot find {expected_name} in {RAW_DIR}"
    )


files = {
    "categories": "categories.csv",
    "customers": "customers.csv",
    "employees": "employees.csv",
    "order_details": "order_details.csv",
    "orders": "orders.csv",
    "products": "products.csv",
    "shippers": "shippers.csv",
    "suppliers": "suppliers.csv",
}

date_columns = {
    "orders": ["OrderDate", "RequiredDate", "ShippedDate"],
    "employees": ["BirthDate", "HireDate"],
}

numeric_columns = {
    "orders": ["Freight"],
    "order_details": ["UnitPrice", "Quantity", "Discount"],
    "products": [
        "UnitPrice",
        "UnitsInStock",
        "UnitsOnOrder",
        "ReorderLevel",
    ],
}

# These fields do not contribute to our analytical calculations.
# Only exclude them if they actually exist in the CSV.
image_columns = {
    "categories": ["Picture"],
    "customers": ["Image", "ImageThumbnail"],
    "employees": ["Photo"],
    "products": ["Picture", "Image", "ImageThumbnail"],
}

summary = []
missing_report = []
conversion_report = []

print("=" * 65)
print("NORTHWIND TRADERS - DATA CLEANING")
print("=" * 65)

for table_name, expected_filename in files.items():

    source_path = find_csv(expected_filename)

    df = pd.read_csv(source_path, encoding="utf-8-sig")
    rows_before = len(df)

    # Standardize column names.
    df.columns = df.columns.astype(str).str.strip()

    # Remove surrounding spaces and turn blank text into missing values.
    text_columns = df.select_dtypes(
        include=["object", "string"]
    ).columns

    for column in text_columns:
        df[column] = df[column].map(
            lambda value: value.strip()
            if isinstance(value, str)
            else value
        )

        df[column] = df[column].replace(
            r"^\s*$", pd.NA, regex=True
        )

    print(f"\nProcessing: {table_name}")
    print(f"Rows: {rows_before}")
    print(f"Source: {source_path.name}")

    # Count full duplicate rows; do not remove them automatically.
    duplicate_rows = int(df.duplicated().sum())

    # Convert date columns and flag invalid non-empty dates.
    for column in date_columns.get(table_name, []):

        if column not in df.columns:
            continue

        original = df[column]

        nonblank = (
            original.notna()
            & original.astype("string").str.strip().ne("")
        )

        converted = pd.to_datetime(
            original, errors="coerce"
        )

        invalid_count = int(
            (nonblank & converted.isna()).sum()
        )

        if invalid_count:
            conversion_report.append({
                "table": table_name,
                "column": column,
                "issue": "Invalid date",
                "count": invalid_count,
            })

        df[column] = converted

    # Convert numeric measures and flag invalid non-empty values.
    for column in numeric_columns.get(table_name, []):

        if column not in df.columns:
            continue

        original = df[column]

        nonblank = (
            original.notna()
            & original.astype("string").str.strip().ne("")
        )

        converted = pd.to_numeric(
            original, errors="coerce"
        )

        invalid_count = int(
            (nonblank & converted.isna()).sum()
        )

        if invalid_count:
            conversion_report.append({
                "table": table_name,
                "column": column,
                "issue": "Invalid numeric value",
                "count": invalid_count,
            })

        df[column] = converted

    # Standardize the discontinued flag when present.
    if "Discontinued" in df.columns:
        flag = df["Discontinued"].astype("string").str.strip().str.lower()

        flag_map = {
            "true": True,
            "false": False,
            "1": True,
            "0": False,
            "yes": True,
            "no": False,
        }

        converted_flag = flag.map(flag_map)

        invalid_flags = int(
            (flag.notna() & converted_flag.isna()).sum()
        )

        if invalid_flags:
            conversion_report.append({
                "table": table_name,
                "column": "Discontinued",
                "issue": "Unrecognized Boolean value",
                "count": invalid_flags,
            })

        df["Discontinued"] = converted_flag.astype("boolean")

    # Remove unnecessary image fields from the analytical copy.
    excluded = [
        column
        for column in image_columns.get(table_name, [])
        if column in df.columns
    ]

    if excluded:
        df = df.drop(columns=excluded)

    # Record missing values in retained analytical columns.
    for column in df.columns:
        missing_count = int(df[column].isna().sum())

        if missing_count > 0:
            missing_report.append({
                "table": table_name,
                "column": column,
                "missing_count": missing_count,
                "missing_percentage": round(
                    missing_count / len(df) * 100, 2
                ) if len(df) else 0,
            })

    # Save clean analytical copies, preserving all rows.
    output_path = CLEAN_DIR / f"{table_name}.csv"

    df.to_csv(
        output_path,
        index=False,
        date_format="%Y-%m-%d",
    )

    summary.append({
        "table": table_name,
        "source_file": source_path.name,
        "rows_before": rows_before,
        "rows_after": len(df),
        "columns_after": len(df.columns),
        "duplicate_rows_flagged": duplicate_rows,
        "missing_cells": int(df.isna().sum().sum()),
        "excluded_image_columns": ", ".join(excluded),
        "output_file": str(output_path.relative_to(ROOT)),
    })

    print(f"Duplicate rows flagged: {duplicate_rows}")
    print(f"Cleaned copy saved: {output_path}")


# Save data-quality reports.
summary_df = pd.DataFrame(summary)

missing_df = pd.DataFrame(
    missing_report,
    columns=[
        "table",
        "column",
        "missing_count",
        "missing_percentage",
    ],
)

conversion_df = pd.DataFrame(
    conversion_report,
    columns=["table", "column", "issue", "count"],
)

summary_df.to_csv(
    OUTPUT_DIR / "data_quality_summary.csv",
    index=False,
)

missing_df.to_csv(
    OUTPUT_DIR / "missing_values_report.csv",
    index=False,
)

conversion_df.to_csv(
    OUTPUT_DIR / "conversion_issues.csv",
    index=False,
)

print("\n" + "=" * 65)
print("CLEANING SUMMARY")
print("=" * 65)
print(summary_df.to_string(index=False))

print("\nInvalid conversions:", len(conversion_report))

if not conversion_df.empty:
    print(conversion_df.to_string(index=False))
else:
    print("No invalid non-empty dates or numeric values found.")

print("\nClean datasets:", CLEAN_DIR)
print("Quality reports:", OUTPUT_DIR)
print("Original CSV files were not modified.")
