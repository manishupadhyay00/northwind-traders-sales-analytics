SELECT COUNT(*) AS employees_count
FROM northwind_traders.employees;

SELECT COUNT(*) AS employees_count
FROM northwind_traders.employees;

SELECT COUNT(*) AS suppliers_count
FROM northwind_traders.suppliers;