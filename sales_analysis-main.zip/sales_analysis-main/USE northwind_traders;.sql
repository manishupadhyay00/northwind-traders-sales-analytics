USE northwind_traders;

SELECT COUNT(*) AS categories_count
FROM categories;

SELECT *
FROM categories;